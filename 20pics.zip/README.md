# 20 pics

This application shows 20 random pics from Flickr using RSS(https://www.flickr.com/services/feeds).
The individual images can be zoomed and panned around while using the details page as a gallery 
swiping left and right, and you can visit the original source too!
Have fun :)

P.S. It was tested only on Android.